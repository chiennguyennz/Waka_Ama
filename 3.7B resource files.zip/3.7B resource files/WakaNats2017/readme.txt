This assessment is developed with support of Nga Kaihoe o Aotearoa, Waka Ama New Zealand.

The data has been provide to be used within an Educational Context. This should not be used to challenge any results within teh waka ama competition as the judges and final verification of results have not been carried out with this data.

